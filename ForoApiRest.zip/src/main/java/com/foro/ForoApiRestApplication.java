
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForoApiRestApplication {
    public static void main(String[] args) {
        SpringApplication.run(ForoApiRestApplication.class, args);
    }
}
